/**
 * 
 */
package com.sterlite.bng.newlogic;

import java.util.Scanner;
import org.apache.log4j.Logger;

/**
 * @author ravi.divvela
 *
 */
public class BsnlBngV2MainCode {

	/**
	 * @param args
	 */
	private static Logger log = Logger.getLogger(BsnlBngV2MainCode.class);
//	Main Method
	public static void main(String[] args) {
		log.info("Main Method Started ");
		BsnlBngV2MainCode bsnlBngV2Main = new BsnlBngV2MainCode();
		bsnlBngV2Main.mainInvokeMethod();
		log.info("Main Method Ended ");
	}
	
//	MainInvokeMethod Starts
	public void mainInvokeMethod(){
		log.info("MainInvokeMethod Method Started ");
		System.out.println("---------- ---------- ---------- ---------- ----------");
		System.out.println("!...	WELCOME TO BSNL-BNG AUTOMATION		...! ");
		System.out.println("---------- ---------- ---------- ---------- ----------");
		System.out.println();
		System.out.println("Provide Input Properties File Path Location : ");
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		String inputPropertiesPath = scanner.next();
	    System.out.println("Given Input Properties FilePath : " + inputPropertiesPath);
		String inputExtension = inputPropertiesPath.substring(inputPropertiesPath.lastIndexOf(".")+1);
		if(!inputExtension.equals("properties")){
			System.out.println();
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------");
			System.out.println("Please Provide File Extension Exact " + "\"." + "properties\" File Name&Location...! ");
			System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------");
			System.exit(1);
		}
		else {
			System.out.println();
			System.out.println("Enter Exact CFG/TXT/LOG File Path Location : ");
			@SuppressWarnings("resource")
			Scanner accessScanner = new Scanner(System.in);
		    String configurationFilePath = accessScanner.next();
		    System.out.println("Given CFG/TXT/LOG FilePath : " + configurationFilePath);
		    String configExtension = configurationFilePath.substring(configurationFilePath.lastIndexOf(".")+1);
			if(configExtension.equals("cfg") || configExtension.equals("txt") || configExtension.equals("log")){
				log.info("Configuration File Extension Match.");
				log.info("");
				BaseAccessConfigRWCode baseAccessConfigRWCode = new BaseAccessConfigRWCode();
				baseAccessConfigRWCode.mainInvokeMethod(inputPropertiesPath, configurationFilePath);
			}// End if CFG/TXT/LOG    
			else{
				System.out.println();
				System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------");
				System.out.println("Given File Extension: '"+ configExtension + "', Please Provide CFG/TXT/LOG File Name&Location...! ");
				System.out.println("---------- ---------- ---------- ---------- ---------- ---------- ---------- ----------");
				log.error("Configuration File Extension not Match. Given Extension is: " + configExtension);
				System.exit(1);
			}
		}
		log.info("MainInvokeMethod Method Ended ");
	}// End Method
	
}// End Class
