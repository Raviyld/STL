/**
 * 
 */
package com.sterlite.bng.access.bo;

import java.util.List;

/**
 * @author ravi.divvela
 *
 */
public class ColonAccessData {
	private String outerUnitNo;
	private String description;
	private String innerUnitStart;
	private String contextName;
	private String sourceIpHost;
	private String loopBack;
//	private List<IpHostMgmtAccessData> ipHosts;
	private List<String> ipHosts;
	/**
	 * @return the outerUnitNo
	 */
	public String getOuterUnitNo() {
		return outerUnitNo;
	}
	/**
	 * @param outerUnitNo the outerUnitNo to set
	 */
	public void setOuterUnitNo(String outerUnitNo) {
		this.outerUnitNo = outerUnitNo;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the innerUnitStart
	 */
	public String getInnerUnitStart() {
		return innerUnitStart;
	}
	/**
	 * @param innerUnitStart the innerUnitStart to set
	 */
	public void setInnerUnitStart(String innerUnitStart) {
		this.innerUnitStart = innerUnitStart;
	}
	/**
	 * @return the contextName
	 */
	public String getContextName() {
		return contextName;
	}
	/**
	 * @param contextName the contextName to set
	 */
	public void setContextName(String contextName) {
		this.contextName = contextName;
	}
	/**
	 * @return the sourceIpHost
	 */
	public String getSourceIpHost() {
		return sourceIpHost;
	}
	/**
	 * @param sourceIpHost the sourceIpHost to set
	 */
	public void setSourceIpHost(String sourceIpHost) {
		this.sourceIpHost = sourceIpHost;
	}
	/**
	 * @return the loopBack
	 */
	public String getLoopBack() {
		return loopBack;
	}
	/**
	 * @param loopBack the loopBack to set
	 */
	public void setLoopBack(String loopBack) {
		this.loopBack = loopBack;
	}
	/**
	 * @return the ipHosts
	 */
	public List<String> getIpHosts() {
		return ipHosts;
	}
	/**
	 * @param ipHosts the ipHosts to set
	 */
	public void setIpHosts(List<String> ipHosts) {
		this.ipHosts = ipHosts;
	}
	/**
	 * @param outerUnitNo
	 * @param description
	 * @param innerUnitStart
	 * @param contextName
	 * @param sourceIpHost
	 * @param loopBack
	 * @param ipHosts
	 */
	public ColonAccessData(String outerUnitNo, String description, String innerUnitStart, String contextName,
			String sourceIpHost, String loopBack, List<String> ipHosts) {
		this.outerUnitNo = outerUnitNo;
		this.description = description;
		this.innerUnitStart = innerUnitStart;
		this.contextName = contextName;
		this.sourceIpHost = sourceIpHost;
		this.loopBack = loopBack;
		this.ipHosts = ipHosts;
	}
	/**
	 * 
	 */
	public ColonAccessData() {
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ColonAccessData [outerUnitNo=" + outerUnitNo + ", description=" + description + ", innerUnitStart="
				+ innerUnitStart + ", contextName=" + contextName + ", sourceIpHost="
				+ sourceIpHost + ", loopBack=" + loopBack + ", ipHost=" + ipHosts + "]";
	}
	
}
